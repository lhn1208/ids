import React from 'react';
import './app.css';
import Habits from './components/habits';

function App() {
  return <Habits></Habits>
  
}

export default App;